known_sentences.concat({
   'Comment Plugin':'Plugin Commentaires<br/><p style="font-size:11px;font-style:normal">Le plugin de commentaire repose sur disqus.com. Inscrivez vous sur ce site et indiquez le "short name" de votre site dans le champ ci-dessous.</p>',
   'comments_activated':'Activer le plugin',
   'disqus_id':'Disqus "site shortname"',
});
