known_sentences.concat({
   'Comment Plugin':'Comments Plugin<br/><p style="font-size:11px;font-style:normal">To give the users the ability to comment your galleries. Register on disqus.com and indicate the "short name" of your site bellow.</p>',
   'comments_activated':'Activate plugin',
   'disqus_id':'Disqus site shortname',
});
