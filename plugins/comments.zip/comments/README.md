plugin-comments
===============

Plugin that empowers EnVadrouille galleries with DISQUS comments.

To install:
* Create the following directory: ./admin/pages/comments
* Put all files of this repository in that directory
* Go in the options and activate the plugin. Do not forget to put your disqus shortname.
