known_sentences.concat({
   'Multi Lang':'Multi Language Description<br/><p style="font-size:12px;font-style:normal">When activated, you can specify your galleries descriptions in multiple languages.</p>',
   'multilang_activated':'Activate plugin',
   'multilang_langs':'Languages (comma separated, no space - e.g., en,fr)',
});

