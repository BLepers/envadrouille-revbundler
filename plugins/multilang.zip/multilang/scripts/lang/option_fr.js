known_sentences.concat({
   'Multi Lang':'Descriptions Multi-langues<br/><p style="font-size:12px;font-style:normal">Permet d\'écrire les descriptions dans plusieurs langues. La langue affichée sera la même que la langue choisie par l\'utilisateur.</p>',
   'multilang_activated':'Activate plugin',
   'multilang_langs':'Langues (séparés par une virgule, sans espace - e.g., en,fr)',
});

