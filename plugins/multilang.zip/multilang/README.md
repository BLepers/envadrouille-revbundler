plugin-multilang
================

Plugin that empowers EnVadrouille with multilingual comments.

To install:
* Create the following directory: ./admin/pages/multilang
* Put all files of this repository in that directory
* Go in the options and activate the plugin.
