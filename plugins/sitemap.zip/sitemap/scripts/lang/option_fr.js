known_sentences.concat({
   'sitemap':'Sitemap',
   'sitemap_activated':'Permettre aux moteurs de recherche d\'indexer vos galeries',
});

