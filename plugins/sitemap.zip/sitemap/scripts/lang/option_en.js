known_sentences.concat({
   'sitemap':'Sitemap',
   'sitemap_activated':'Make your galleries visible by search engines',
});

