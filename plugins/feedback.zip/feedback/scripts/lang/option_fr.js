known_sentences.concat({
   'Feedback Plugin':'Plugin Feedback',
   'feedback_activated':'Activer le plugin',
   'feedback_mail':'Adresse email à laquelle envoyer le feedback',
});
