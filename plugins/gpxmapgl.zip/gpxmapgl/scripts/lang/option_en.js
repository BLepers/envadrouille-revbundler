known_sentences.concat({
   'GPX Mapbox Isochrones':'GPX Mapbox Isochrones<br/><p style="font-size:12px;font-style:normal">Display your GPX traces on top of isochrone maps. See https://github.com/BLepers/isochrones-gtfs to generate the tilesets. Then go to <a href="../#!isomap">the isomap</a>. Requires the GPX Map plugin to work.',
   gpxmapgl_activated:'Activate GPX GL Map plugin',
   gpxmapgl_token:'Mapbox Public Token',
   gpxmapgl_tileset:'Mapbox Tileset to display',
});
