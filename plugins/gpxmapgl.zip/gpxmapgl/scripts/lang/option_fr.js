known_sentences.concat({
   'GPX Mapbox Isochrones':'GPX Mapbox Isochrones<br/><p style="font-size:12px;font-style:normal">Affiche vos traces GPX sur une carte isochrone de transport en commun. Voir https://github.com/BLepers/isochrones-gtfs pour générer le tileset. Ensuite vous pouvez <a href="../#!isomap">afficher la carte</a>. Nécessite le plugin GPX Map pour fonctionner.',
   gpxmapgl_activated:'Activer le plugin GPX GL Map',
   gpxmapgl_token:'Mapbox Public Token',
   gpxmapgl_tileset:'Mapbox Tileset à afficher',
});
