known_sentences.concat({
   gpxmap_activated:'Activer le plugin GPX Map',
   gpxmap_default_map:'Carte par défaut',
});
