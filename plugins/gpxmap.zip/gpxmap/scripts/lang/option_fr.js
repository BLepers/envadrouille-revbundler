known_sentences.concat({
   gpxmap_activated:'Activer le plugin GPX Map',
});
