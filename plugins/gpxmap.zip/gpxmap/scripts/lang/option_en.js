known_sentences.concat({
   gpxmap_activated:'Activate GPX Map plugin',
});
