known_sentences.concat({
   'rss':'Rss',
   'rss_activated':'Créer un flux RSS (/rss.xml)',
});

