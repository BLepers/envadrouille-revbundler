known_sentences.concat({
   'rss':'RSS',
   'rss_activated':'Create a RSS feed (/rss.xml)',
});

